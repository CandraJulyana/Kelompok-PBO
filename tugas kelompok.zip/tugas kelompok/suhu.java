import java.util.Scanner;

public class suhu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan suhu dalam Celsius: ");
        double celsius = scanner.nextDouble();

        // Konversi suhu dari Celsius ke Fahrenheit
        double fahrenheit = celsiusToFahrenheit(celsius);

        // Mencetak hasil konversi dengan presisi 2 desimal
        System.out.printf("%.2f Celsius = %.2f Fahrenheit\n", celsius, fahrenheit);

        scanner.close();
    }

    // Method untuk mengonversi suhu dari Celsius ke Fahrenheit
    public static double celsiusToFahrenheit(double celsius) {
        return (celsius * 9 / 5) + 32;
    }
}

