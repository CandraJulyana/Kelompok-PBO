import java.util.Scanner;

public class deret {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan sebuah bilangan bulat: ");
        int number = scanner.nextInt();

        printNumberSeries(number);

        scanner.close();
    }

    // Method untuk mencetak deret angka ditambah tanda '*'
    public static void printNumberSeries(int n) {
        for (int i = 1; i <= n; i++) {
            // Mencetak angka
            System.out.print(i);
            // Mencetak '*' jika bukan angka terakhir
            for (int j = 0; j < i; j++) {
                
                System.out.print("*");
            }
           
            System.out.println(); // Pindah ke baris baru setelah mencetak deret
        }
    }
}
