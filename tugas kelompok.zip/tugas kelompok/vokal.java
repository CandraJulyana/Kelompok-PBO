import java.util.Scanner;

public class vokal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan sebuah kalimat: ");
        String sentence = scanner.nextLine().toLowerCase(); // Mengubah kalimat menjadi huruf kecil untuk mempermudah perhitungan

        int vowelCount = countVowels(sentence);

        System.out.println("Jumlah huruf vokal dalam kalimat: " + vowelCount);

        scanner.close();
    }

    // Method untuk menghitung jumlah huruf vokal dalam sebuah kalimat
    public static int countVowels(String sentence) {
        int count = 0;
        for (int i = 0; i < sentence.length(); i++) {
            char ch = sentence.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                count++;
            }
        }
        return count;
    }
}
