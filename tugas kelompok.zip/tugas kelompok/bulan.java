import java.util.Scanner;

public class bulan {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan nomor bulan (1-12): ");
        int monthNumber = scanner.nextInt();

        // Mengecek apakah nomor bulan berada dalam rentang yang valid
        if (monthNumber >= 1 && monthNumber <= 12) {
            String monthName = getMonthName(monthNumber);
            System.out.println("Nama bulan: " + monthName);
        } else {
            System.out.println("Input tidak valid. Masukkan nomor bulan antara 1 dan 12.");
        }

        scanner.close();
    }

    // Method untuk mendapatkan nama bulan berdasarkan nomor bulan
    public static String getMonthName(int monthNumber) {
        String monthName;
        switch (monthNumber) {
            case 1:
                monthName = "Januari";
                break;
            case 2:
                monthName = "Februari";
                break;
            case 3:
                monthName = "Maret";
                break;
            case 4:
                monthName = "April";
                break;
            case 5:
                monthName = "Mei";
                break;
            case 6:
                monthName = "Juni";
                break;
            case 7:
                monthName = "Juli";
                break;
            case 8:
                monthName = "Agustus";
                break;
            case 9:
                monthName = "September";
                break;
            case 10:
                monthName = "Oktober";
                break;
            case 11:
                monthName = "November";
                break;
            case 12:
                monthName = "Desember";
                break;
            default:
                monthName = "Tidak Valid";
        }
        return monthName;
    }
}
