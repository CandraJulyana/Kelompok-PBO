import java.util.Scanner;

public class prima {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan bilangan: ");
        int number = scanner.nextInt();

        if (isPrime(number)) {
            System.out.println(number + " adalah bilangan prima.");
        } else {
            System.out.println(number + " bukan bilangan prima.");
        }

        scanner.close();
    }

    // Method untuk mengecek apakah suatu bilangan prima
    public static boolean isPrime(int n) {
        // Angka kurang dari 2 bukan prima
        if (n <= 1) {
            return false;
        }
        // Loop dari 2 hingga akar dari n
        for (int i = 2; i <= Math.sqrt(n); i++) {
            // Jika n bisa dibagi habis oleh i, maka bukan prima
            if (n % i == 0) {
                return false;
            }
        }
        // Jika tidak ada pembagi selain 1 dan n itu sendiri, maka bilangan prima
        return true;
    }
}
