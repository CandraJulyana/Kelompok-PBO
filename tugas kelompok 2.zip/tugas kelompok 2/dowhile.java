import java.util.Scanner;

public class dowhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int totalPositif = 0;
        int bilangan;

        System.out.println("Masukkan bilangan positif (masukkan bilangan negatif untuk berhenti):");

        do {
            System.out.print("Masukkan bilangan: ");
            bilangan = scanner.nextInt();

            if (bilangan >= 0) {
                totalPositif += bilangan;
            }
        } while (bilangan >= 0);

        System.out.println("Total bilangan positif yang dimasukkan: " + totalPositif);
    }
}
