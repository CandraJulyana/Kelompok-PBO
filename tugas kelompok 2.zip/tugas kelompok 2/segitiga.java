public class segitiga {
    public static void main(String[] args) {
        int tinggi = 5; // tinggi segitiga

        // Loop untuk baris
        for (int i = 0; i < tinggi; i++) {
            // Loop untuk kolom, mencetak spasi sebelum bintang
            for (int j = 0; j < i; j++) {
                System.out.print(" ");
            }

            // Loop untuk mencetak bintang, dimulai dari tinggi dan dikurangi setiap baris
            for (int k = tinggi; k > i; k--) {
                System.out.print("* ");
            }

            // Pindah ke baris berikutnya
            System.out.println();
        }
    }
}
