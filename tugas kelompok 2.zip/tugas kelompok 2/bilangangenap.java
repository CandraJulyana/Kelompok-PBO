public class bilangangenap {
    public static void main(String[] args) {
        // Loop for untuk mencetak deret bilangan genap dari 2 hingga 20
        for (int i = 2; i <= 20; i += 2) {
            System.out.println(i);
        }
    }
}
