public class bilanganganjil {
    public static void main(String[] args) {
        int i = 1;
        // Loop while untuk mencetak deret bilangan ganjil dari 1 hingga 15
        while (i <= 15) {
            System.out.println(i);
            i += 2; // Menambahkan 2 setiap iterasi untuk melompati bilangan genap
        }
    }
}
