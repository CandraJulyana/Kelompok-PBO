public class segitigaangka {
    public static void main(String[] args) {
        int tinggi = 5; // tinggi segitiga
        int nilai = 1; // nilai awal

        // Loop untuk baris
        for (int i = 1; i <= tinggi; i++) {
            // Loop untuk spasi sebelum angka
            for (int j = 1; j <= tinggi - i; j++) {
                System.out.print(" ");
            }

            // Loop untuk mencetak angka
            for (int k = 1; k <= i; k++) {
                System.out.print(nilai + " ");
                nilai++;
            }

            // Pindah ke baris baru
            System.out.println();
        }
    }
}
